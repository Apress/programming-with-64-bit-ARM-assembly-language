//
//  upper.h
//  ToUpper
//
//  Created by Stephen Smith on 2020-01-24.
//  Copyright © 2020 Stephen Smith. All rights reserved.
//

#ifndef upper_h
#define upper_h

extern int mytoupper(const char *, char *);

#endif /* upper_h */
