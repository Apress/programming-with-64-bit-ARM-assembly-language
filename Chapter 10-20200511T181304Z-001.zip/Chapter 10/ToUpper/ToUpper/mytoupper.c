//
//  mytoupper.c
//  ToUpper
//
//  Created by Stephen Smith on 2020-01-24.
//  Copyright © 2020 Stephen Smith. All rights reserved.
//

#include <stdio.h>
